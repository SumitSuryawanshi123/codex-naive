"""Shared application helpers."""
