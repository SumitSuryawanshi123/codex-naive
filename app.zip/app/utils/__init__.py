"""Shared application helpers."""
