"""Application configuration package."""
