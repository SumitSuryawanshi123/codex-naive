"""FastAPI route package."""
