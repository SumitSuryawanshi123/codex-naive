"""FastAPI route package."""
