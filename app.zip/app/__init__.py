"""CRM tickets demo application."""
